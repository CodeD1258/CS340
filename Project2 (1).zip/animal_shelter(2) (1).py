from pymongo import MongoClient

class AnimalShelter:
    """CRUD operations for the AAC animals collection"""

    def __init__(self, user, password, host, port, db_name, collection_name):
        # Initialize MongoDB client and select database and collection
        self.client = MongoClient(f"mongodb://{user}:{password}@{host}:{port}")
        self.db = self.client[db_name]
        self.collection = self.db[collection_name]


    def create(self, data):
        if data:
            try:
                self.collection.insert_one(data)
                return True
            except Exception as e:
                print(f"Insert failed: {e}")
                return False
        else:
            raise ValueError("Nothing to save, the data parameter is empty")

    def read(self, query):
        if query is None:
            query = {}
        try:
            result = self.collection.find(query)
            return list(result)
        except Exception as e:
            print(f"Read failed: {e}")
            return[]

        else:
            raise ValueError("Query parameter is empty")
     
    def update(self, query, update_data):
        if query and update_data:
            try:
                result = self.collection.update_many(query, {'$set': update_data})
                return result.modified_count
            except Exception as e:
                print(f"Error updating data: {e}")
                return 0

        else: 
                print("Query or update data missing.")
                return 0


    def delete(self,query):
        if query:
            try: 
                result = self.collection.delete_many(query)
                return result.deleted_count
            except Exception as e:
                print(f"Error deleting data: {e}")
                return 0

        else:
                print("No query provided.")
                return 0










